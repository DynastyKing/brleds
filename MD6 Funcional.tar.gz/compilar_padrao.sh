rm md6_padrao
gcc -w -o md6_padrao compression_function.c constants.c modes.c md6\ 2.c nist.c

