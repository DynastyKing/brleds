rm md6_padrao
gcc -o md6_padrao compression_function.c constants.c modes.c md6\ 2.c nist.c

