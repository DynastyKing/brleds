rm md6_modificado
gcc -o md6_modificado compression_function.c constants.c modes.c md6.c nist.c

